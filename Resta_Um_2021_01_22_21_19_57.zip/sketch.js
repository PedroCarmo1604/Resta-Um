function setup() {
  
  createCanvas(500, 500);
  button = createButton("Resolução");
  button.position(380, 400);
  button.mousePressed(solucao);
}

function draw() {
  background(imagemTabuleiro);
  inicioTabuleiro();
    
}

function apagaBolinha(a){
  
  splice(xBolinha[a], yBolinha[a]);
}

function solucao(){
  function movimentaBolinha(xy, x, y, a, t){
    setTimeout(function(){
    
    xBolinha[xy] = x;
    yBolinha[xy] = y;
    
    xBolinha[a] = apagaBolinha;
    yBolinha[a] = apagaBolinha
    }, t)
  }

  movimentaBolinha(27, 248, 255, 22, 1000);
  movimentaBolinha(24, 248, 319, 23, 2000);
  movimentaBolinha(31, 316, 319, 28, 3000);
  movimentaBolinha(29, 316, 449, 30, 4000);
  movimentaBolinha(16, 316, 387, 31, 5000);
  movimentaBolinha(29, 316, 319, 16, 6000);
  movimentaBolinha(5, 316, 255, 10, 7000);
  movimentaBolinha(12, 316, 193, 11, 8000);
  movimentaBolinha(25, 452, 193, 18, 9000);
  movimentaBolinha(9, 384, 193, 12, 10000);
  movimentaBolinha(25, 316, 193, 9, 11000);
  movimentaBolinha(7, 248, 193, 8, 12000);
  movimentaBolinha(0, 181, 193, 3, 13000);
  movimentaBolinha(15, 181, 129, 0, 14000);
  movimentaBolinha(2, 181, 65, 1, 15000);
  movimentaBolinha(2, 181, 193, 15, 16000);
  movimentaBolinha(26, 181, 255, 21, 17000);
  movimentaBolinha(19, 181, 319, 20, 18000);
  movimentaBolinha(6, 46, 319, 13, 19000);
  movimentaBolinha(24, 114, 319, 19, 20000);
  movimentaBolinha(6, 181, 319, 24, 21000);
  movimentaBolinha(7, 384, 193, 25, 22000);
  movimentaBolinha(7, 384, 319, 17, 23000);
  movimentaBolinha(7, 248, 319, 29, 24000);
  movimentaBolinha(7, 114, 319, 6, 25000);
  movimentaBolinha(7, 114, 193, 14, 26000);
  movimentaBolinha(7, 248, 193, 2, 27000);
  movimentaBolinha(27, 384, 255, 5, 28000);
  movimentaBolinha(4, 248, 255, 7, 29000);
  movimentaBolinha(26, 316, 255, 4, 30000);
  movimentaBolinha(27, 248, 255, 26, 31000);
}
