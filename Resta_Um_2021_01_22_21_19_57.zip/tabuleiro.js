let imagemTabuleiro;

function preload(){
  
  imagemTabuleiro = loadImage("imagens/tabuleiro.png");
}

function inicioTabuleiro(){
  
  for(let i = 0; i <= 32; i++){
    if(i != 16){
      
      desenhaBolinhas(xBolinha[i], yBolinha[i]);
    }
  }
}